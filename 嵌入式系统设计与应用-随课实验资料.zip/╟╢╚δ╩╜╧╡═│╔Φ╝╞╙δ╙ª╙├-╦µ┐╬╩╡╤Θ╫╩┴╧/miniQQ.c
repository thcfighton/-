/***********************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <termios.h>
#include <time.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
/***********************************************/
#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>
#include <minigui/control.h>
#define IDC_CONFIRM            101
#define IDC_QUIT                102
#define IDC_ID                   103
#define IDC_PWD                 104
#define IDC_STATIC1              105
#define IDC_STATIC2              106

#define ID_button_up   		139
#define ID_button_down   		140
#define ID_button_stand  		141

#define ID_key_up   		142
#define ID_key_down   		143
#define ID_key_stand  		144
#define IDC_STATIC3             145
#define IDC_STATIC4              146


//以下为软键盘控件ID定义
#define IDC_ZERO                120
#define IDC_ONE                 121
#define IDC_TWO                 122
#define IDC_THREE               123
#define IDC_FOUR                124
#define IDC_FIVE                 125
#define IDC_SIX                  126
#define IDC_SEVEN               127
#define IDC_EIGHT               128
#define IDC_NINE                129
#define IDC_POINT               130
#define IDC_BACKSPACE          131
#define IDC_LCOK                132
#define IDC_LCQT                133
#define IDC_LCQT1                134
#define IDC_LCDP                135
#define IDC_RECEIVE             136
#define IDC_SEND                137
#define IDC_LCXT                138
#define IDC_A                   147
#define IDC_B                   148
#define IDC_C                   149
#define IDC_D                   150
#define IDC_RS                  151	
#define IDC_BS                  152
#define SERVPORT 				3333


//登录用户名密码
#define USER  "666"
#define PASSWD "666"

static char user[20]={1,2,3};
static char passwd[20]={4,5,6};
static  HWND 					hwndListBox;
static  HWND  SEND;
static  HWND  button_up;
static  HWND  button_down;
static  HWND  button_stand;
static  BITMAP bmp1,bmp2,bmp3,bmp4,bmp5;


static  HWND  key_up;
static  HWND  key_down;
static  HWND  key_stand;
static  BITMAP bmp11,bmp22,bmp33;



static BITMAP bmp_bkgnd;
static BITMAP bmp_bkgnd1;

static char str_buf_send[50];
static char str_buf_receive[50];
int g3,g4,sd;  


//socket编程
char send_buf[50]={0};
char receive_buf[100]={0};
int sockfd, sendbytes,recvbytes;
struct sockaddr_in serv_addr;
char buff_recv[100];	
char * buff_send = "123!\n";

LISTBOXITEMINFO 				lbiisend;//发送方（listbox用到的变量）
LISTBOXITEMINFO 				lbiireceive;//接收方



//socket编程函数部分
void client()
{
	/*创建socket*/
	if ((sockfd=socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		return ;
	}
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(SERVPORT);
	inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);
	
	/*调用connect函数，连接服务器端*/
	if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr)) == -1) {
		perror("connect");
		return ;
	}
}
void client_send(char *buff_send)
{
	/*调用send函数，发送数据*/
	if((sendbytes=send(sockfd, buff_send , strlen(buff_send ),0)) == -1) {
		perror("send");
		return ;
	} 
	printf("To Server:  %s\n",buff_send);
}
void client_receive()
{
	/*调用recv函数接收客户端的请求*/
	recvbytes=recv(sockfd,buff_recv,100,0);//100是接收缓冲区的最大长度
	buff_recv[recvbytes] = '\0';
	printf("From Server:  %s\n",buff_recv);
}
void client_close()
{
	close(sockfd);
}


  
    
/***********************************************/
/*******登录成功对话框*****************************/
/***********************************************/
static DLGTEMPLATE LoginSuccessfullyDlg = {
	WS_BORDER | WS_CAPTION,
	WS_EX_NONE,
	0, 0, 240, 320,
	"Login Successfully",
	0, 0, //Icon and Menu
	12, NULL, //Number of controls
	0
};
/***********************************************/
/*******登录成功对话框控件定义***********************/
/***********************************************/
static CTRLDATA LoginSuccessfullyCtrl [] = {
                {                  "static",
	                          WS_CHILD | SS_NOTIFY | SS_SIMPLE | WS_VISIBLE,
	                          10, 90, 80, 20,IDC_STATIC3,
                                  "Receive",0
                 },
                 {                  "static",
	                          WS_CHILD | SS_NOTIFY | SS_SIMPLE | WS_VISIBLE,
	                          10, 130, 80, 20,IDC_STATIC4,
                                  "Send",0
                 },
                {             "edit",
	                     WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOWRAP,
	                    90, 90, 140, 20,IDC_RECEIVE,"",0
                },
                 {             "edit",
	                     WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOWRAP,
	                    90, 130, 140, 20,IDC_SEND,"",0
                },

	{
		"button",
		WS_TABSTOP | WS_VISIBLE | BS_DEFPUSHBUTTON,
		130, 170, 69, 20,
		IDC_LCQT1,
		"Quit",
		0
	},

	{
		"button",
		WS_TABSTOP | WS_VISIBLE | BS_DEFPUSHBUTTON,
		10, 170, 80, 20,
		IDC_LCDP,
		"Send",
		0
	},
        {      
             "button",
	      WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
              25,211,45,25,
              IDC_A,"A",
              0
         }, {      
             "button",
	      WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
             70,211,45,25,
              IDC_B,"B",
              0
         },{      
             "button",
	      WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
              115,211,45,25,
              IDC_C,"C",
              0
         },{      
             "button",
	      WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
              160,211,45,25,
              IDC_D,"D",
              0
         },{      
             "button",
	      WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
              25,236,45,25,
              IDC_RS,"Reset",
              0
         },{      
             "button",
	      WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
              160,236,45,25,
              IDC_BS,"<-",
              0
         }
} ;



    

/***********************************************/
/*******登录成功对话框回调函数***********************/
/***********************************************/
static int LoginSuccessfullyInitDialogBoxProc (HWND hDlg, int message, WPARAM wParam, LPARAM lParam)
{ 

	switch (message) {
		case MSG_INITDIALOG:
                client();
		return 1;
		break;
		case MSG_ERASEBKGND: {
			HDC hdc = (HDC)wParam;
			const RECT* clip = (const RECT*) lParam;
			BOOL fGetDC = FALSE;
			RECT rcTemp;

			if (hdc == 0) {
				hdc = GetClientDC (hDlg);
				fGetDC = TRUE;
			}

			if (clip) {
				rcTemp = *clip;
				ScreenToClient (hDlg, &rcTemp.left, &rcTemp.top);
				ScreenToClient (hDlg, &rcTemp.right, &rcTemp.bottom);
				IncludeClipRect (hdc, &rcTemp);
			}

	
		FillBoxWithBitmap (hdc, 0, 0, 240, 320, &bmp_bkgnd);

			if (fGetDC)
				ReleaseDC (hdc);
			return 0;
		}


		case MSG_COMMAND:{
		 int id1 = LOWORD (wParam);
		int code1= HIWORD (wParam);
		switch (id1) {
                case IDC_SEND:
    SEND=GetDlgItem(hDlg,IDC_SEND);
       // printf("123");
      
   if(code1 == EN_CLICKED){printf("0"); 
                 sd=1;}
                 break;
                case IDC_A:if(sd){
                  
                    str_buf_send[g3++]='A';
                     str_buf_send[g3]='\0';}
                 SetWindowText (SEND, str_buf_send);
                  break;
                  case IDC_B:if(sd){
                 
                   str_buf_send[g3++]='B';
                     str_buf_send[g3]='\0';}
                SetWindowText (SEND, str_buf_send);
                  break;     
                  case IDC_C:if(sd){
                
                   str_buf_send[g3++]='C';
                     str_buf_send[g3]='\0';}
                 SetWindowText (SEND, str_buf_send);
                  break;
                  case IDC_D:if(sd){
                 
                  str_buf_send[g3++]='D';
                     str_buf_send[g3]='\0';}
               SetWindowText (SEND, str_buf_send);
                  break;
                  case IDC_RS:
                  while(sd&&(g3>0))
                 {   g3--;
                     str_buf_send[g3]='\0';}
                  SetWindowText (SEND, str_buf_send);
                  break;
                  case IDC_BS:
                  if(sd&&(g3>0))
                 {   g3--;
                     str_buf_send[g3]='\0';
                 SetWindowText (SEND, str_buf_send);}
                  break;
                 case IDC_LCDP:
                 GetWindowText(SEND,send_buf,50);
					if(strlen(send_buf)!=0)
					{
						client_send(send_buf);
						lbiisend.string =send_buf;
						SendMessage(hwndListBox, LB_ADDSTRING, -1, (LPARAM)&lbiisend);
                     strcat(str_buf_receive,str_buf_send);
                     SetWindowText (GetDlgItem(hDlg,IDC_RECEIVE), str_buf_receive);
                      
						while(g3>0)
                 {   g3--;
                     str_buf_send[g3]='\0';}
                  SetWindowText (SEND, str_buf_send);
                     strcpy(str_buf_receive,"");
						client_receive();
						lbiireceive.string =buff_recv;
						SendMessage (hwndListBox, LB_ADDSTRING,-1, (LPARAM)&lbiireceive);
					}
                       break;
                
                 case IDC_LCQT1:
                    client_close();
			EndDialog (hDlg, wParam);
                     
			break;
}
}
}
	return DefaultDialogProc (hDlg, message, wParam, lParam);
}
 
 
 
static void LoginSuccessfullyDialogInit (HWND hWnd){

	/* 将对话框模板结构和控件结构数组关联起来 */
	LoginSuccessfullyDlg.controls = LoginSuccessfullyCtrl;
	DialogBoxIndirectParam (&LoginSuccessfullyDlg, hWnd,LoginSuccessfullyInitDialogBoxProc, 0L);
 }   


                     
                           
                 

	                       
                  

/***********************************************/
/*******登录失败对话框*****************************/
/***********************************************/
static DLGTEMPLATE LoginFalseDlg = {
	WS_BORDER | WS_CAPTION,
	WS_EX_NONE,
	0, 0, 240, 320,
	"Login Failed",
	0, 0, //Icon and Menu
	1, NULL, //Number of controls
	0
};
/***********************************************/
/*******登录失败对话框控件定义***********************/
/***********************************************/
static CTRLDATA LoginFalseCtrl [] = {

	{
		"button",
		WS_TABSTOP | WS_VISIBLE | BS_DEFPUSHBUTTON,
		140, 250, 50, 30,
		IDC_LCQT,
		"Quit",
		0
	}

};

/***********************************************/
/*******登录失败对话框回调函数***********************/
/***********************************************/
static int LoginFalseInitDialogBoxProc (HWND hDlg, int message, WPARAM wParam, LPARAM lParam)
{
	switch (message) {
		case MSG_INITDIALOG:
		return 1;
		break;
		case MSG_ERASEBKGND: {
			HDC hdc = (HDC)wParam;
			const RECT* clip = (const RECT*) lParam;
			BOOL fGetDC = FALSE;
			RECT rcTemp;

			if (hdc == 0) {
				hdc = GetClientDC (hDlg);
				fGetDC = TRUE;
			}

			if (clip) {
				rcTemp = *clip;
				ScreenToClient (hDlg, &rcTemp.left, &rcTemp.top);
				ScreenToClient (hDlg, &rcTemp.right, &rcTemp.bottom);
				IncludeClipRect (hdc, &rcTemp);
			}

	
		FillBoxWithBitmap (hdc, 0, 0, 240, 320, &bmp_bkgnd);

			if (fGetDC)
				ReleaseDC (hdc);
			return 0;
		}
               
		case MSG_COMMAND:
		switch (wParam) {

			case IDC_LCQT:
			EndDialog (hDlg, wParam);
                     
			break;
		}
		break;
                case MSG_DESTROY:
		DestroyAllControls (hDlg);
		break;
	}
	return DefaultDialogProc (hDlg, message, wParam, lParam);
}
static void LoginFalseDialogInit (HWND hWnd)
{
	/* 将对话框模板结构和控件结构数组关联起来 */
	LoginFalseDlg.controls = LoginFalseCtrl;
	DialogBoxIndirectParam (&LoginFalseDlg, hWnd, LoginFalseInitDialogBoxProc, 0L);

}

/***********************************************/
/*******简单软键盘所用变量**************************/
/***********************************************/
static HWND bd_zero,bd_one,bd_two,bd_three,bd_four,bd_five,bd_six,bd_seven,bd_eight,bd_nine,bd_point,bd_backspace;
static char str_bufgl[20];
static char str_buf_id[20];
static char str_buf_pwd[20];
int  gl=0, g2=0, g3=0, usr1=0, pwd1=0;

/***********************************************/
//以下为软键盘控件定义
/***********************************************/
static void create_softkeyboard (HWND hWnd)
{
	int DEC_X,DEC_Y;
	DEC_X=50;
	DEC_Y=50;

	bd_zero = CreateWindow(CTRL_BUTTON,
	                       "0",
	                       WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                       IDC_ZERO,
	                       0.5*DEC_X, 3*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                       hWnd,
	                       0);
	bd_one = CreateWindow(CTRL_BUTTON,
	                      "1",
	                      WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                      IDC_ONE,
	                      1.5*DEC_X-5, 3*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                      hWnd,
	                      0);
	bd_two = CreateWindow(CTRL_BUTTON,
	                      "2",
	                      WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                      IDC_TWO,
	                      2.5*DEC_X-10, 3*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                      hWnd,
	                      0);
	bd_three = CreateWindow(CTRL_BUTTON,
	                        "3",
	                        WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                        IDC_THREE,
	                        3.5*DEC_X-15, 3*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                        hWnd,
	                        0);
	bd_four = CreateWindow(CTRL_BUTTON,
	                       "4",
	                       WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                       IDC_FOUR,
	                       0.5*DEC_X, 3.5*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                       hWnd,
	                       0);
	bd_five = CreateWindow(CTRL_BUTTON,
	                       "5",
	                       WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                       IDC_FIVE,
	                       1.5*DEC_X-5, 3.5*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                       hWnd,
	                       0);
	bd_six = CreateWindow(CTRL_BUTTON,
	                      "6",
	                      WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                      IDC_SIX,
	                      2.5*DEC_X-10, 3.5*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                      hWnd,
	                      0);
	bd_seven = CreateWindow(CTRL_BUTTON,
	                        "7",
	                        WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                        IDC_SEVEN,
	                        3.5*DEC_X-15, 3.5*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                        hWnd,
	                        0);
	bd_eight = CreateWindow(CTRL_BUTTON,
	                        "8",
	                        WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                        IDC_EIGHT,
	                        0.5*DEC_X, 4*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                        hWnd,
	                        0);
	bd_nine = CreateWindow(CTRL_BUTTON,
	                       "9",
	                       WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                       IDC_NINE,
	                       1.5*DEC_X-5, 4*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                       hWnd,
	                       0);
	bd_point = CreateWindow(CTRL_BUTTON,
	                        ".",
	                        WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                        IDC_POINT,
	                        2.5*DEC_X-10, 4*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                        hWnd,
	                        0);
	bd_backspace = CreateWindow(CTRL_BUTTON,
	                            "<-",
	                            WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
	                            IDC_BACKSPACE,
	                            3.5*DEC_X-15, 4*DEC_Y+61, DEC_X-5, DEC_Y/2,
	                            hWnd,
	                            0);

}

/***********************************************/
//主窗口控件句柄定义
/***********************************************/
static HWND bd_c, bd_q, ed_id, ed_pwd, static_id, static_pwd;
/***********************************************/

/*****************主窗口按钮和edit控件***************/
/***********************************************/
static void create_buttons(HWND hWnd)
{
	/**********************************************/
     LoadBitmapFromFile(HDC_SCREEN, &bmp4, "./loginid.bmp");
	static_id = CreateWindowEx (CTRL_STATIC,
	                          "",
	                          WS_CHILD | SS_NOTIFY | SS_SIMPLE | WS_VISIBLE  | SS_BITMAP ,WS_EX_TRANSPARENT,
	                          IDC_STATIC1,
	                          10, 50, 80, 20,
	                          hWnd,(DWORD)&bmp4
	                          );
     ShowWindow(static_id,SW_SHOW);

	/***********************************************/
LoadBitmapFromFile(HDC_SCREEN, &bmp5, "./loginpwd.bmp");
	static_pwd = CreateWindowEx (CTRL_STATIC,
	                           "",
	                           WS_CHILD | SS_NOTIFY | SS_SIMPLE | WS_VISIBLE | SS_BITMAP ,WS_EX_TRANSPARENT,
	                           IDC_STATIC2,
	                           10, 90, 80, 20,
	                           hWnd,(DWORD)&bmp5
	                           );
 ShowWindow(static_pwd,SW_SHOW);
	/********************用户名输入框******************/
	ed_id = CreateWindow(CTRL_EDIT,
	                     "",
	                     WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOWRAP,
	                     IDC_ID,
	                    90, 50, 140, 20,
	                     hWnd,
	                     0);
	/********************密码输入框******************/
	ed_pwd = CreateWindow (CTRL_EDIT,
	                       "",
	                       WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOWRAP | ES_PASSWORD,
	                       IDC_PWD,
	                       90, 90, 140, 20,
	                       hWnd,
	                       0);
	
}
static int MiniQQWinProc(HWND hWnd, int message, WPARAM wParam, LPARAM lParam)
{
	int x=LOWORD(lParam);
	int y=HIWORD(lParam);
	HDC hdc;
switch (message) {
case MSG_ERASEBKGND: {
		HDC hdc = (HDC)wParam;
		const RECT* clip = (const RECT*) lParam;
		BOOL fGetDC = FALSE;
		RECT rcTemp;

		if (hdc == 0) {
			hdc = GetClientDC (hWnd);
			fGetDC = TRUE;
		}

		if (clip) {
			rcTemp = *clip;
			ScreenToClient (hWnd, &rcTemp.left, &rcTemp.top);
			ScreenToClient (hWnd, &rcTemp.right, &rcTemp.bottom);
			IncludeClipRect (hdc, &rcTemp);
		}

		

		if (fGetDC)
			ReleaseDC (hdc);
		return 0;
	}
case MSG_CREATE:
		LoadBitmapFromFile (HDC_SCREEN, &bmp_bkgnd, "./111.bmp");
		FillBoxWithBitmap (hdc, 0, 0, 240, 320, &bmp_bkgnd);
		create_buttons (hWnd);
                create_softkeyboard(hWnd);
LoadBitmapFromFile(HDC_SCREEN, &bmp1, "./Login1.bmp");
		button_up=
		        CreateWindowEx (CTRL_STATIC, "", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_NOTIFY,
		                        WS_EX_TRANSPARENT,
		                        ID_button_up, 10,
		                        170, 80, 20, hWnd, (DWORD)&bmp1);

		ShowWindow(button_up,SW_SHOW);
		
				LoadBitmapFromFile(HDC_SCREEN, &bmp11, "./key3.bmp");
		key_up=
		        CreateWindowEx (CTRL_STATIC, "", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_NOTIFY,
		                        WS_EX_TRANSPARENT,
		                        ID_key_up, 130,
		                        170, 69, 20, hWnd, (DWORD)&bmp11);

		
		ShowWindow(key_up,SW_SHOW);
		break;
case MSG_COMMAND: {
		int id = LOWORD (wParam);
		int code = HIWORD (wParam);
		switch (id) {
                case ID_key_up:
               create_softkeyboard(hWnd);
                 break;
		case ID_button_up:
           
		  if(!strcmp(USER,str_buf_id)&&!strcmp(PASSWD,str_buf_pwd)){
                    printf("login successfully\n");
                      LoginSuccessfullyDialogInit(hWnd);}

                   else
			
			{         printf("login failed!!!\n");
				  LoginFalseDialogInit(hWnd);
                          };


			break;
		case IDC_ID:
			if(code == EN_CLICKED) {
				usr1 = 1 ;
				pwd1 = 0 ;

			}
			break;
		case IDC_ZERO:

			if (usr1) {
				str_buf_id[g2++] = '0';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '0';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_ONE:
			if (usr1) {
				str_buf_id[g2++] = '1';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '1';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_TWO:
			if (usr1) {
				str_buf_id[g2++] = '2';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '2';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_THREE:
			if (usr1) {
				str_buf_id[g2++] = '3';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '3';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_FOUR:
			if (usr1) {
				str_buf_id[g2++] = '4';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '4';



				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_FIVE:
			if (usr1) {
				str_buf_id[g2++] = '5';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '5';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_SIX:
			if (usr1) {
				str_buf_id[g2++] = '6';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '6';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_SEVEN:
			if (usr1) {
				str_buf_id[g2++] = '7';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '7';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_EIGHT:
			if (usr1) {
				str_buf_id[g2++] = '8';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '8';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_NINE:
			if (usr1) {
				str_buf_id[g2++] = '9';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '9';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_POINT:
			if (usr1) {
				str_buf_id[g2++] = '.';
				str_buf_id[g2] = '\0';

				SetWindowText (ed_id, str_buf_id);

			}
			if (pwd1) {
				str_buf_pwd[g3++] = '.';
				str_buf_pwd[g3] = '\0';

				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;
		case IDC_BACKSPACE:

			if ((usr1)&&(g2 > 0)) {
				g2--;
				str_buf_id[g2] = '\0';
				SetWindowText (ed_id, str_buf_id);
			}
			if ((pwd1)&&(g3 > 0)) {
				g3--;
				str_buf_pwd[g3] = '\0';
				SetWindowText (ed_pwd, str_buf_pwd);
			}
			break;

		case IDC_PWD:
			if(code == EN_CLICKED) {
				pwd1 = 1 ;
				usr1 = 0 ;
			}
			break;

		case IDC_QUIT:
			printf ("退出程序功能需添加!\n");
			DestroyWindow(hWnd);
			break;
		}
	}
	break;

case MSG_DESTROY:
		DestroyAllControls (hWnd);
		break;

	case MSG_CLOSE:
		DestroyMainWindow (hWnd);
		PostQuitMessage (hWnd);
		break;
	default:
		return DefaultMainWinProc(hWnd, message, wParam, lParam);
	}
	return(0);
}
/***********************************************/
int MiniGUIMain (int argc, const char* argv[])
{

	MSG Msg;
	HWND hMainWnd;
	MAINWINCREATE CreateInfo;

#ifdef _LITE_VERSION
	SetDesktopRect(0, 0, 240, 320);
#endif

	CreateInfo.dwStyle = WS_VISIBLE | WS_BORDER | WS_CAPTION;
	CreateInfo.dwExStyle = WS_EX_NONE;
	CreateInfo.spCaption = "2020212342 2020212374";
	CreateInfo.hMenu = 0;
	CreateInfo.hCursor = GetSystemCursor(0);
	CreateInfo.hIcon = 0;
	CreateInfo.MainWindowProc = MiniQQWinProc;
	CreateInfo.lx = 0;
	CreateInfo.ty = 0;
	CreateInfo.rx = 240;
	CreateInfo.by = 320;
	CreateInfo.iBkColor = COLOR_lightwhite;
	CreateInfo.dwAddData = 0;
	CreateInfo.hHosting = HWND_DESKTOP;

	hMainWnd = CreateMainWindow (&CreateInfo);

	if (hMainWnd == HWND_INVALID)
		return -1;

	ShowWindow(hMainWnd, SW_SHOWNORMAL);

	while (GetMessage(&Msg, hMainWnd)) {
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}

	MainWindowThreadCleanup (hMainWnd);

	return 0;

}

#ifndef _LITE_VERSION
#include <minigui/dti.c>
#endif







