#include <stdio.h>
#include <stdlib.h>
#include <string.h>    
#include <unistd.h>      
#include <sys/types.h>   
#include <fcntl.h>       
#include <termios.h>    
#include <time.h>
/***********************************************/
#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>
#include <minigui/control.h>
/***********************************************/


/***********************************************/
#define IDC_CONFIRM              101
#define IDC_DISP                 102
#define IDC_QUIT                 103
#define IDC_SUBDLG_QUIT 		 104
/***********************************************/
static HWND bd_c, bd_q, ed_text;
static char str_buf1[30]="hello my miniQQ!";
static char str_buf2[30]="hello it has been displayed!";
static char str_buf3[30]="hello i want to quit!";
/***********************************************/
/*******�����������ñ���**************************/
#define ITEM_NUM	10

static const char* caption[] =
{
   "0", "1", "2", "3", "4", "5","6", "7", "8", "9"
};
#ifdef _LANG_ZHCN
static const char* hint[] =
{
   "���� 0", "���� 1", "���� 2", "���� 3", "���� 4", 
   "���� 5", "���� 6", "���� 7", "���� 8", "���� 9"
};
#else
static const char* hint[] =
{
   "Number 0", "Number 1", "Number 2", "Number 3", "Number 4", 
   "Number 5", "Number 6", "Number 7", "Number 8", "Number 9"
};
#endif
/***********************************************/
//����Ϊ�����̿ؼ�����
/***********************************************/
static void create_coolbar (HWND hWnd)
{
    HWND cb;
    COOLBARITEMINFO item;
    int i;

    cb = CreateWindow (CTRL_COOLBAR,
                    "",
                    WS_CHILD | WS_VISIBLE | WS_BORDER, 
                    100,
                    10, 100, 100, 20,
                    hWnd,
                    0);

    item.ItemType = TYPE_TEXTITEM;
    item.Bmp = NULL;
    item.dwAddData = 0;
    for (i = 0; i < ITEM_NUM; i++) {
		item.insPos = i;
		item.id = i;
		item.Caption = caption[i];
		item.ItemHint = hint[i];
		SendMessage (cb, CBM_ADDITEM, 0, (LPARAM)&item);
    }
}
/***********************************************/

static void create_buttons(HWND hWnd)
{   
    /***********************************************/
   bd_c = CreateWindow(CTRL_BUTTON,
		"Confirm ȷ��",
        WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
		IDC_CONFIRM,
        10, 210, 100, 50,
        hWnd,
        0);  
   bd_q = CreateWindow(CTRL_BUTTON,
        "Cancle ȡ��",
        WS_CHILD | BS_PUSHBUTTON | WS_VISIBLE | WS_TABSTOP,
		IDC_QUIT,
        120, 210, 100, 50, 
        hWnd,
        0);
}

//�Ӵ��ڶ���
static DLGTEMPLATE SubDlg = {
	WS_BORDER | WS_CAPTION,
	WS_EX_NONE,
	0, 0, 240, 320,
	"�Ӵ���",
	0, 0, //Icon and Menu
	1, NULL, //Number of controls
	0
};
/*******�Ӵ��ڿؼ�����***********************/

/***********************************************/
static CTRLDATA SubDlgCtrl [] = {

	{
		"button",
		WS_TABSTOP | WS_VISIBLE | BS_DEFPUSHBUTTON,
		170, 250, 50, 30,
		IDC_SUBDLG_QUIT,
		"Quit",
		0
	}

};

static BITMAP bmp_bkgnd;
/*******�Ӵ��ڻص�����***********************/
/***********************************************/
static int SubDialogProc (HWND hDlg, int message, WPARAM wParam, LPARAM lParam)
{
	switch (message) {
		case MSG_INITDIALOG:
			return 1;
			break;
		case MSG_CLOSE:
			EndDialog (hDlg, wParam);
			break;
		case MSG_ERASEBKGND: {
			HDC hdc = (HDC)wParam;
			const RECT* clip = (const RECT*) lParam;
			BOOL fGetDC = FALSE;
			RECT rcTemp;

			if (hdc == 0) {
				hdc = GetClientDC (hDlg);
				fGetDC = TRUE;
			}

			if (clip) {
				rcTemp = *clip;
				ScreenToClient (hDlg, &rcTemp.left, &rcTemp.top);
				ScreenToClient (hDlg, &rcTemp.right, &rcTemp.bottom);
				IncludeClipRect (hdc, &rcTemp);
			}

			FillBoxWithBitmap (hdc, 0, 0, 240, 300, &bmp_bkgnd);
			
			if (fGetDC)
				ReleaseDC (hdc);
			return 0;
		}

		case MSG_COMMAND:
			switch (wParam) {
			case IDC_SUBDLG_QUIT:
				EndDialog (hDlg, wParam);
			break;
		}
		break;
	}
	return DefaultDialogProc (hDlg, message, wParam, lParam);
}
static void SubDialogInit (HWND hWnd)
{
	/* ���Ի���ģ��ṹ�Ϳؼ��ṹ����������� */
	SubDlg.controls = SubDlgCtrl;
	DialogBoxIndirectParam (&SubDlg, hWnd, SubDialogProc, 0L);
}

/***********************************************/
static int CoolbarWinProc(HWND hWnd, int message, WPARAM wParam, LPARAM lParam)
{
   static HWND ed;
   switch (message) {
    case MSG_CREATE:
    LoadBitmap (HDC_SCREEN, &bmp_bkgnd, "./qq.jpg");
		ed = CreateWindow (CTRL_EDIT,
			"",
			WS_CHILD | WS_VISIBLE | WS_BORDER, 
			200,
			10, 10, 100, 20,
			hWnd,
			0);
		create_coolbar(hWnd);
		create_buttons (hWnd);                
		break;
    case MSG_COMMAND:
	{
	    int id = LOWORD (wParam);
	    int code = HIWORD (wParam);
            if (id == 100) {
                PostMessage (ed, MSG_CHAR, '0' + code, 0);
	    }
	    switch (id)
	    {	
                case IDC_CONFIRM:
                        SetWindowText (ed_text, str_buf1); 
                        SubDialogInit(hWnd);
                        break;
                case IDC_DISP:
                        SetWindowText (ed_text, str_buf2);
	    		break;
                case IDC_QUIT:
                        SetWindowText (ed_text, str_buf3);
	    		break;
	     }
        }
	break;
 
    case MSG_DESTROY:
        DestroyAllControls (hWnd);
	break;

    case MSG_CLOSE:
        DestroyMainWindow (hWnd);
        PostQuitMessage (hWnd);
        break;
    default:
        return DefaultMainWinProc(hWnd, message, wParam, lParam);
    }
    return(0); 
    
}
/***********************************************/
/***********************************************/
/***********************************************/
int MiniGUIMain (int argc, const char* argv[])
{
    MSG Msg;
    HWND hMainWnd;
    MAINWINCREATE CreateInfo;        

#ifdef _LITE_VERSION
    SetDesktopRect(0, 0, 1024, 768);
#endif



    CreateInfo.dwStyle = WS_CAPTION | WS_BORDER | WS_VISIBLE;
    CreateInfo.dwExStyle = WS_EX_NONE;
    CreateInfo.spCaption = "���� mini QQ";
    CreateInfo.hMenu = 0;
    CreateInfo.hCursor = GetSystemCursor(IDC_ARROW);
    CreateInfo.hIcon = 0;
    CreateInfo.MainWindowProc = CoolbarWinProc;       //modified by Guo Lei
    CreateInfo.lx = 0; 
    CreateInfo.ty = 0;
    CreateInfo.rx = 240;
    CreateInfo.by = 320;
    CreateInfo.iBkColor = COLOR_lightwhite;
    CreateInfo.dwAddData = 0;
    CreateInfo.dwReserved = 0;
    CreateInfo.hHosting = HWND_DESKTOP;

    hMainWnd = CreateMainWindow (&CreateInfo);
    if (hMainWnd == HWND_INVALID)
        return -1;

    ShowWindow(hMainWnd, SW_SHOWNORMAL);
    
   
    while (GetMessage(&Msg, hMainWnd)) {
        TranslateMessage(&Msg);
        DispatchMessage(&Msg);
    }

    MainWindowThreadCleanup (hMainWnd);

    return 0;
}

#ifndef _LITE_VERSION
#include <minigui/dti.c>
#endif

