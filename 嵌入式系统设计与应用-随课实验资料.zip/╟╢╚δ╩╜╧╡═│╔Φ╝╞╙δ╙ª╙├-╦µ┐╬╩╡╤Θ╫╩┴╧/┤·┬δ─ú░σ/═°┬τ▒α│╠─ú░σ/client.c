#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>


#define SERVPORT 3333
#define MAXDATASIZE 100


int main(int argc, char** argv)
{
	char* server_addr;
	if (argc == 1) {
		server_addr = "127.0.0.1";
	} else if (argc == 2) {
		server_addr = argv[1];
	} else {
		printf("Usage: ./client [server address] []\ne.g. ./client 127.0.0.1\n");
	}
	
	int sockfd, sendbytes;
	struct sockaddr_in serv_addr;
	char* buff = "Hello World!";
	
	
	if ((sockfd=socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		return -1;
	}
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(SERVPORT);
	inet_pton(AF_INET, server_addr, &serv_addr.sin_addr);
	//bzero(&(serv_addr.sin_zero), 8);

	if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr)) == -1) {
		perror("connect");
		return -1;
	}
	if((sendbytes=send(sockfd, buff, strlen(buff),0)) == -1) {
		perror("send");
		return -1;
	} else {
		printf("Send [%s] to %s\n", buff, server_addr);
	}
	close(sockfd);

	return 0;
}
