#include <stdio.h>
#include <string.h>
#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>

#include <minigui/control.h>

#define ID_button_up     100
#define ID_button_down   101
#define ID_timer         102
static  HWND  hMainWnd;
static  HWND  button_up;
static  HWND  button_down;
static  BITMAP bmp1,bmp2;




void callback_button(HWND hwnd, int id, int nc, DWORD add_data)
{
     SetTimer (hMainWnd, ID_timer, 20);
     ShowWindow(button_up,SW_HIDE);
     ShowWindow(button_down,SW_SHOW);
     printf("Button clicked!\n ");//add your code here 
    
     
}

static int HelloWinProc(HWND hWnd, int message, WPARAM wParam, LPARAM lParam)
{
    switch (message) {
        case MSG_CREATE:
             LoadBitmapFromFile(HDC_SCREEN, &bmp1, "./d1.bmp");
             button_up=
              CreateWindowEx (CTRL_STATIC, "", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_NOTIFY,
                          WS_EX_TRANSPARENT,
                          ID_button_up, 10,
                          10, 73, 80, hWnd, (DWORD)&bmp1);
             SetNotificationCallback (button_up, callback_button);



             LoadBitmapFromFile(HDC_SCREEN, &bmp2, "./d2.bmp");
             button_down=
              CreateWindowEx (CTRL_STATIC, "", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_NOTIFY,
                          WS_EX_TRANSPARENT,
                          ID_button_down,10,
                          10, 73, 80, hWnd, (DWORD)&bmp2);

             ShowWindow(button_down,SW_HIDE);
             ShowWindow(button_up,SW_SHOW);
            
             
             break;


        case MSG_TIMER:
             ShowWindow(button_down,SW_HIDE);
             ShowWindow(button_up,SW_SHOW);
             KillTimer (hWnd, ID_timer);
             break;
        case MSG_CLOSE:
             DestroyMainWindow (hWnd);
             PostQuitMessage (hWnd);
             return 0;
    }

    return DefaultMainWinProc(hWnd, message, wParam, lParam);
}


int MiniGUIMain (int argc, const char* argv[])
{
    MSG Msg;
    MAINWINCREATE CreateInfo;

#ifdef _LITE_VERSION
    SetDesktopRect(0, 0, 1024, 768);
#endif

    CreateInfo.dwStyle = WS_VISIBLE | WS_BORDER | WS_CAPTION;
    CreateInfo.dwExStyle = WS_EX_NONE;
    CreateInfo.spCaption = "This is lively button";
    CreateInfo.hMenu = 0;
    CreateInfo.hCursor = GetSystemCursor(0);
    CreateInfo.hIcon = 0;
    CreateInfo.MainWindowProc = HelloWinProc;
    CreateInfo.lx = 0;
    CreateInfo.ty = 0;
    CreateInfo.rx = 240;
    CreateInfo.by = 320;
    CreateInfo.iBkColor = COLOR_lightwhite;
    CreateInfo.dwAddData = 0;
    CreateInfo.hHosting = HWND_DESKTOP;
    
    hMainWnd = CreateMainWindow (&CreateInfo);
    
    if (hMainWnd == HWND_INVALID)
        return -1;

    ShowWindow(hMainWnd, SW_SHOWNORMAL);

    while (GetMessage(&Msg, hMainWnd)) {
        TranslateMessage(&Msg);
        DispatchMessage(&Msg);
    }

    MainWindowThreadCleanup (hMainWnd);

    return 0;
}

#ifndef _LITE_VERSION
#include <minigui/dti.c>
#endif

