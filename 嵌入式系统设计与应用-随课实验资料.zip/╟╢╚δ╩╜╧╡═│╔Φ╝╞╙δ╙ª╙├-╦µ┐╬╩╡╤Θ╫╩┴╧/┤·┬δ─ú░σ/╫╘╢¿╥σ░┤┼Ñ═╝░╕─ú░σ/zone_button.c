#include <stdio.h>
#include <string.h>
#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>
#include <minigui/control.h>


static  HWND  hMainWnd;
static  HWND  button_up;
static  HWND  button_down;
static  BITMAP bmp1,bmp2;

#define IDC_SKINBUTTONUP      502
#define IDC_SKINBUTTONDOWN   503
#define IDC_QUITASK             504




static int HelloWinProc(HWND hWnd, int message, WPARAM wParam, LPARAM lParam)
{
    HDC hdc;
    int x=LOWORD(lParam);
    int y=HIWORD(lParam);
    switch (message) {
        case MSG_CREATE:
             
             LoadBitmapFromFile(HDC_SCREEN, &bmp1, "./d1.bmp");
             button_up=
              CreateWindowEx (CTRL_STATIC, "", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_NOTIFY,
                          WS_EX_TRANSPARENT,
                          IDC_SKINBUTTONUP, 10,
                          10, 73, 80, hWnd, (DWORD)&bmp1);

             LoadBitmapFromFile(HDC_SCREEN, &bmp2, "./d2.bmp");
             button_down=
              CreateWindowEx (CTRL_STATIC, "", WS_CHILD | WS_VISIBLE | SS_BITMAP | SS_NOTIFY,
                          WS_EX_TRANSPARENT,
                          IDC_SKINBUTTONDOWN,10,
                          10, 73, 80, hWnd, (DWORD)&bmp2);

             ShowWindow(button_down,SW_HIDE);
             ShowWindow(button_up,SW_SHOW);
             SendMessage(hWnd,MSG_PAINT,0,0);
             break;
         case MSG_PAINT:
             hdc=BeginPaint(hWnd);
             EndPaint(hWnd,hdc);
             return 0;
         case MSG_LBUTTONDOWN:
                         if(y > 20 && y<100 && x>20 && x<93)
                        {
                         ShowWindow(button_up,SW_HIDE);
                         ShowWindow(button_down,SW_SHOWNORMAL);
                         SendMessage(hWnd,MSG_PAINT,0,0); 
                        }         
             break;
        case MSG_LBUTTONUP:
                         if(y > 20 && y<100 && x>20 && x<93)
                        {
                         ShowWindow(button_down,SW_HIDE);
                         ShowWindow(button_up,SW_SHOWNORMAL);
                         SendMessage(hWnd,MSG_PAINT,0,0);
                       }    
             break;

        case MSG_CLOSE:
             DestroyMainWindow (hWnd);
             PostQuitMessage (hWnd);
             return 0;
    }

    return DefaultMainWinProc(hWnd, message, wParam, lParam);
}


int MiniGUIMain (int argc, const char* argv[])
{
    MSG Msg;
    MAINWINCREATE CreateInfo;

#ifdef _LITE_VERSION
    SetDesktopRect(0, 0, 1024, 768);
#endif

    CreateInfo.dwStyle = WS_VISIBLE | WS_BORDER | WS_CAPTION;
    CreateInfo.dwExStyle = WS_EX_NONE;
    CreateInfo.spCaption = "This is lively button";
    CreateInfo.hMenu = 0;
    CreateInfo.hCursor = GetSystemCursor(0);
    CreateInfo.hIcon = 0;
    CreateInfo.MainWindowProc = HelloWinProc;
    CreateInfo.lx = 0;
    CreateInfo.ty = 0;
    CreateInfo.rx = 240;
    CreateInfo.by = 320;
    CreateInfo.iBkColor = COLOR_lightwhite;
    CreateInfo.dwAddData = 0;
    CreateInfo.hHosting = HWND_DESKTOP;
    
    hMainWnd = CreateMainWindow (&CreateInfo);
    
    if (hMainWnd == HWND_INVALID)
        return -1;

    ShowWindow(hMainWnd, SW_SHOWNORMAL);

    while (GetMessage(&Msg, hMainWnd)) {
        TranslateMessage(&Msg);
        DispatchMessage(&Msg);
    }

    MainWindowThreadCleanup (hMainWnd);

    return 0;
}

#ifndef _LITE_VERSION
#include <minigui/dti.c>
#endif

